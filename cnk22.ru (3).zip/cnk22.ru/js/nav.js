let downButton = document.querySelector('.down-button');

downButton.onclick = function () {
  window.scrollTo(100, 100);
};
